Groupwork was done by pair programming. 
